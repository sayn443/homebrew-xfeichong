#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
natmap_client.py - macOS 客户端本地TCP转发脚本

用法:
    xfeichong-client                 # 守护模式（brew services / launchd 托管）
    xfeichong-client init            # 仅生成配置模板 ~/.xfeichong/config.json
    xfeichong-client -c /path/cfg    # 指定配置文件路径

流程:
    1. 读取配置文件（默认 ~/.xfeichong/config.json，缺失时自动生成模板并等待编辑）
    2. 轮询 server 获取外部映射地址（customer-server 未上线则等待）
    3. 本地监听 local_port，将所有流量转发到获取到的外部地址

守护模式设计（供 brew services 常驻）:
    - 任何错误（配置未就绪/server 暂时不可达/appkey 未上线）都退避重试，不退出进程
    - 日志输出到 stdout，由 launchd 重定向到 Homebrew 日志文件
"""

import argparse
import json
import os
import shutil
import socket
import select
import threading
import time
import sys
from pathlib import Path
from urllib.request import urlopen
from urllib.parse import urlencode
from urllib.error import HTTPError, URLError

# ===================== 默认配置 =====================
CONFIG_DIR = Path.home() / ".xfeichong"
DEFAULT_CONFIG = CONFIG_DIR / "config.json"
DEFAULT_SERVER_URL = "https://xfeichong.com"
POLL_INTERVAL = 5          # 轮询server的间隔（秒）
CONNECT_TIMEOUT = 10       # 转发连接超时（秒）
CONFIG_WAIT_INTERVAL = 30  # 守护模式下配置模板生成后等待编辑的检查间隔（秒）
PLACEHOLDER_APPKEY = "你的APPKEY"

CONFIG_TEMPLATE = {
    "server_url": DEFAULT_SERVER_URL,
    "appkey": PLACEHOLDER_APPKEY,
    "local_port": 8889
}
# ====================================================


def write_template(path):
    """生成配置模板：优先拷贝与脚本同目录捆绑的 config.json（brew 安装时打包的模板），
    否则用内置占位模板。"""
    path.parent.mkdir(parents=True, exist_ok=True)
    bundled = Path(__file__).resolve().with_name("config.json")
    if bundled.exists() and bundled.resolve() != path.resolve():
        shutil.copy(bundled, path)
    else:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(CONFIG_TEMPLATE, f, ensure_ascii=False, indent=4)
            f.write("\n")


def load_config(path):
    with open(path, "r", encoding="utf-8") as f:
        cfg = json.load(f)
    for key in ("appkey", "local_port"):
        if key not in cfg:
            raise ValueError(f"配置文件缺少必填项: {key}")
    if not str(cfg["appkey"]).strip() or str(cfg["appkey"]).strip() == PLACEHOLDER_APPKEY:
        raise ValueError(f"appkey 尚未配置（请编辑 {path} 填入真实 appkey）")
    cfg["local_port"] = int(cfg["local_port"])
    return cfg


def wait_config_ready(path):
    """守护模式：配置缺失则生成模板，并周期等待用户编辑到合法为止。"""
    if not path.exists():
        write_template(path)
        print(f"[+] 已生成配置模板: {path}", flush=True)
        print(f"[*] 请编辑该文件填入 appkey 后保存，客户端将自动继续（每 {CONFIG_WAIT_INTERVAL} 秒检查一次）...", flush=True)
    while True:
        try:
            return load_config(path)
        except FileNotFoundError:
            pass
        except (ValueError, json.JSONDecodeError) as e:
            print(f"[-] 配置尚未就绪: {e}，{CONFIG_WAIT_INTERVAL} 秒后重试...", flush=True)
        except OSError as e:
            print(f"[-] 配置文件读取失败: {e}，{CONFIG_WAIT_INTERVAL} 秒后重试...", flush=True)
        time.sleep(CONFIG_WAIT_INTERVAL)


def query_address(server_url, appkey):
    """查询server端映射地址。返回 (host, port)；未上线返回 None；appkey无效抛异常。"""
    url = server_url.rstrip("/") + "/api/query/?" + urlencode({"appkey": appkey})
    try:
        with urlopen(url, timeout=10) as resp:
            data = json.loads(resp.read().decode())
    except HTTPError as e:
        try:
            msg = json.loads(e.read().decode()).get("msg")
        except Exception:
            msg = f"HTTP {e.code}"
        raise RuntimeError(f"查询失败: {msg}")
    if not data.get("ok"):
        raise RuntimeError(data.get("msg", "未知错误"))
    if not data.get("online"):
        return None
    return (data["host"], int(data["port"]))


def wait_for_address(server_url, appkey, poll_interval=POLL_INTERVAL):
    """轮询直到拿到映射地址（customer-server 上线并上报后）。守护模式下永不退出。"""
    attempt = 0
    backoff = poll_interval
    while True:
        attempt += 1
        try:
            addr = query_address(server_url, appkey)
            backoff = poll_interval
        except (URLError, OSError) as e:
            print(f"[-] 第 {attempt} 次查询网络错误: {e}，{backoff} 秒后重试...", flush=True)
            time.sleep(backoff)
            backoff = min(backoff * 2, 60)
            continue
        except RuntimeError as e:
            print(f"[-] {e}，{backoff} 秒后重试...", flush=True)
            time.sleep(backoff)
            backoff = min(backoff * 2, 60)
            continue
        if addr:
            print(f"[+] 第 {attempt} 次查询: 获取到外部地址 {addr[0]}:{addr[1]}", flush=True)
            return addr
        print(f"[*] 第 {attempt} 次查询: customer-server 尚未上线，{poll_interval}秒后重试...", flush=True)
        time.sleep(poll_interval)


def fwd(a, b):
    """双向转发的一侧"""
    try:
        while True:
            d = a.recv(65535)
            if not d:
                break
            b.sendall(d)
    except (OSError, BrokenPipeError, ConnectionResetError):
        pass


def handle(client_sock, client_addr, remote_addr):
    """将本地连接转发到远程映射地址"""
    remote = None
    try:
        remote = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        remote.settimeout(CONNECT_TIMEOUT)
        remote.connect(remote_addr)
        remote.settimeout(None)
        t1 = threading.Thread(target=fwd, args=(client_sock, remote), daemon=True)
        t2 = threading.Thread(target=fwd, args=(remote, client_sock), daemon=True)
        t1.start(); t2.start()
        t1.join(); t2.join()
    except Exception as e:
        print(f"[{time.strftime('%H:%M:%S')}] [-] {client_addr} 转发错误: {e}", flush=True)
    finally:
        for s in (client_sock, remote):
            if s:
                try:
                    s.close()
                except Exception:
                    pass


def accept_loop(listen_sock, remote_addr):
    while True:
        try:
            readable, _, _ = select.select([listen_sock], [], [], 1.0)
            if not readable:
                continue
            cs, ca = listen_sock.accept()
            print(f"[{time.strftime('%H:%M:%S')}] [+] 连接 {ca[0]}:{ca[1]} -> {remote_addr[0]}:{remote_addr[1]}", flush=True)
            threading.Thread(target=handle, args=(cs, ca, remote_addr), daemon=True).start()
        except OSError as e:
            if e.errno == 9:  # EBADF
                break
        except Exception:
            pass


def run_daemon(config_path):
    """守护模式：等待配置就绪 -> 等待映射地址 -> 本地转发（全程不退出）"""
    while True:
        cfg = wait_config_ready(config_path)
        server_url = cfg.get("server_url") or DEFAULT_SERVER_URL
        appkey = cfg["appkey"]
        local_port = int(cfg["local_port"])

        print(f"[*] 配置: server={server_url} appkey={appkey} 本地端口={local_port}", flush=True)

        # 1. 轮询等待外部地址
        remote_addr = wait_for_address(server_url, appkey)

        # 2. 本地监听
        listen_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        listen_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            listen_sock.bind(("127.0.0.1", local_port))
            listen_sock.listen(65535)
        except OSError as e:
            print(f"[-] 本地端口 {local_port} 监听失败: {e}，60 秒后重试（或编辑配置更换端口）...", flush=True)
            time.sleep(60)
            continue
        print(f"[+] 本地监听: 127.0.0.1:{local_port}", flush=True)
        print(f"[+] 转发目标: {remote_addr[0]}:{remote_addr[1]}", flush=True)

        # 3. 转发循环（异常不退出，等待 customer-server 重新上线后重新拿地址）
        try:
            accept_loop(listen_sock, remote_addr)
        except Exception as e:
            print(f"[-] 转发循环异常: {e}，重新查询映射地址...", flush=True)
        finally:
            try:
                listen_sock.close()
            except Exception:
                pass


def main():
    parser = argparse.ArgumentParser(
        description="xfeichong 客户端：本地TCP转发到NAT映射地址",
        epilog="brew services 管理示例: brew services start xfeichong-client")
    parser.add_argument("command", nargs="?", choices=["init"], default=None,
                        help="init = 仅生成配置模板并退出（默认为守护模式）")
    parser.add_argument("--config", "-c", default=str(DEFAULT_CONFIG),
                        help=f"配置文件路径（默认 {DEFAULT_CONFIG}）")
    args = parser.parse_args()
    config_path = Path(os.path.expanduser(args.config))

    if args.command == "init":
        if config_path.exists():
            print(f"[*] 配置文件已存在，不覆盖: {config_path}")
        else:
            write_template(config_path)
            print(f"[+] 已生成配置模板: {config_path}")
            print(f"[*] 请编辑该文件填入 appkey，然后运行: xfeichong-client（或 brew services start xfeichong-client）")
        return

    run_daemon(config_path)


if __name__ == "__main__":
    main()
