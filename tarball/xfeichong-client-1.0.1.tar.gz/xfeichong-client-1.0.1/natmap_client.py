#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
natmap_client.py - macOS 客户端本地TCP转发脚本

用法:
    xfeichong-client                 # 守护模式（brew services / launchd 托管）
    xfeichong-client init            # 仅生成配置模板 ~/.xfeichong/config.json
    xfeichong-client -c /path/cfg    # 指定配置文件路径

配置文件（~/.xfeichong/config.json）支持两种写法：

  ── 自动模式（推荐）────────────────────────────────────────────────────
    一个客户端只绑定一个 appkey，自动把该 appkey 名下的「所有映射」映射到本机：

        {
            "appkey": "XBD7S3XC",
            "local_ports": {"3389": 46234}
        }

    - 客户端会向平台枚举该 appkey 下的全部映射，为每一条建立本地转发；
    - 每条映射的「本地监听端口」默认为该映射的「远端映射端口」
      （即旧写法里的 remote_local_port，也就是远端设备上那条映射的 local_port）；
      -- 远端端口未知（UPnP 自动分配还没回填）时，退而使用它的公网端口。
    - local_ports 可选，用来把某条映射改到指定端口：{"3389": 46234} 表示
      「远端端口为 46234 的那条映射，在本机监听 3389」；键 = 本地监听端口，
      值 = 远端映射端口。没写进 local_ports 的映射按上面的默认端口走。
    - 映射是动态的：平台上新增 / 删除映射后，客户端会自动增删对应的本地监听，
      配置无需改动、服务无需重启。

  ── 兼容模式（旧写法，仍支持）──────────────────────────────────────────
    一个数组，每个元素固定一条「本地端口 -> 远端映射」的转发任务：

        [
          {"appkey": "XXXX", "local_port": 8889, "remote_local_port": 4674},
          {"appkey": "XXXX", "local_port": 8890, "remote_local_port": 4675}
        ]

每个转发任务做的事:
    1. 本地监听 127.0.0.1:<本地监听端口>
    2. 转发目标优先级: 配置的「远程服务器内网地址(remote_lan_addr)」> 平台查到的「公网映射地址」
    3. 后台探测线程实时探测当前目标是否可达:
       - 内网地址不可达        -> 立即改用平台上的公网地址
       - 公网地址不可达        -> 重新向平台查询，地址有变更则切换并重试
       - 换了地址仍然不可达    -> 判定为异常，指数退避后继续重试
       - 内网地址恢复可达      -> 自动切回内网优先直连

平台地址写死在程序里（DEFAULT_SERVER_URL），配置文件里不再需要 server_url；
本地联调可用环境变量 XFEICHONG_SERVER_URL 临时覆盖。

守护模式设计（供 brew services 常驻）:
    - 任何错误（配置未就绪/平台暂时不可达/appkey 未上线）都退避重试，不退出进程
    - 单个任务出错只影响该任务，其余任务继续工作
    - 自动模式下周期性向平台枚举映射，自动增删本地监听任务
    - 日志输出到 stdout，由 launchd 重定向到 Homebrew 日志文件
"""

import argparse
import json
import os
import re
import shutil
import socket
import select
import threading
import time
from pathlib import Path
from urllib.request import urlopen
from urllib.parse import urlencode
from urllib.error import HTTPError, URLError

# ===================== 默认配置 =====================
CONFIG_DIR = Path.home() / ".xfeichong"
DEFAULT_CONFIG = CONFIG_DIR / "config.json"
# 平台地址写死在程序里（配置文件不再提供该项）。
# 仅本地联调需要指到别的地址时，用环境变量临时覆盖：XFEICHONG_SERVER_URL=http://127.0.0.1:8000
DEFAULT_SERVER_URL = "https://xfeichong.com"
SERVER_URL = os.environ.get("XFEICHONG_SERVER_URL", "").strip() or DEFAULT_SERVER_URL
POLL_INTERVAL = 5          # 轮询server的间隔（秒）
CONNECT_TIMEOUT = 10       # 转发连接超时（秒）
CONFIG_WAIT_INTERVAL = 30  # 守护模式下配置模板生成后等待编辑的检查间隔（秒）
PROBE_INTERVAL = 10        # 可达性探测间隔（秒）
PROBE_TIMEOUT = 3          # 单次可达性探测超时（秒）
LAN_RECHECK_INTERVAL = 60  # 已切到公网后，回探内网地址的间隔（秒）
TASK_RETRY_INTERVAL = 30   # 单个转发任务异常后的重试间隔（秒）
DISCOVER_INTERVAL = 10     # 自动模式：向平台枚举该 appkey 映射的间隔（秒）
DAEMON_TICK = 2            # 守护主循环节拍（秒）
PLACEHOLDER_APPKEY = "你的APPKEY"

# 配置模板（自动模式）：一个客户端只绑定一个 appkey，自动映射它名下的所有映射。
CONFIG_TEMPLATE = {
    "appkey": PLACEHOLDER_APPKEY,
    # 本地监听端口 -> 远端映射端口。留空 {} = 全部按默认端口映射
    # （默认端口即该映射的远端端口）。
    # 例: {"3389": 46234} = 把远端端口为 46234 的那条映射放到本机 3389 上监听。
    "local_ports": {},
    # 以下三项是可选的探测参数，一般不用改：
    "probe_interval": PROBE_INTERVAL,              # 可达性探测间隔（秒）
    "probe_timeout": PROBE_TIMEOUT,                # 单次探测超时（秒）
    "lan_recheck_interval": LAN_RECHECK_INTERVAL,  # 走公网后回探内网的间隔（秒）
}
# ====================================================

# 未加引号的端口键（{3389: 46234}）—— 用户很容易这么写，做个兼容
_BARE_KEY_RE = re.compile(r'([{,]\s*)(\d+)(\s*:)')


def now():
    return time.strftime('%H:%M:%S')


def fmt_addr(addr):
    return f"{addr[0]}:{addr[1]}" if addr else "无"


def parse_addr(value, default_port=0):
    """把 "host:port" 解析成 (host, port)；端口可省略（用 default_port 兜底）"""
    if not value:
        return None
    text = str(value).strip()
    if not text:
        return None
    if ":" in text:
        host, _, port_text = text.rpartition(":")
        host = host.strip()
        try:
            port = int(port_text)
        except ValueError:
            raise ValueError(f"地址格式错误: {value}（应为 主机:端口）")
    else:
        host, port = text, int(default_port or 0)
    if not host:
        raise ValueError(f"地址格式错误: {value}（主机为空）")
    if not 0 < port < 65536:
        raise ValueError(f"地址格式错误: {value}（端口无效，可填写 remote_local_port 兜底）")
    return (host, port)


def _positive_int(item, key, default):
    """读取一个必须 > 0 的整数配置项（缺省/空串用 default）"""
    value = item.get(key)
    try:
        value = int(value) if value not in (None, "") else default
    except (TypeError, ValueError):
        raise ValueError(f"{key} 不是数字: {item.get(key)!r}")
    if value <= 0:
        raise ValueError(f"{key} 必须大于 0: {value}")
    return value


def _probe_params(item):
    """从配置对象里取出三项探测参数（可选，缺省用默认值）"""
    return {
        "probe_interval": _positive_int(item, "probe_interval", PROBE_INTERVAL),
        "probe_timeout": _positive_int(item, "probe_timeout", PROBE_TIMEOUT),
        "lan_recheck_interval": _positive_int(item, "lan_recheck_interval",
                                              LAN_RECHECK_INTERVAL),
    }


def _loads_lenient(text):
    """解析配置文本，并兼容「local_ports 的键没加引号」这种常见笔误。

    标准 JSON 的对象键必须加引号（{"3389": 46234}），但用户很容易照直觉写成
    {3389: 46234} —— 严格解析会直接失败、报错信息也不直观。这里在严格解析失败后，
    只给「紧跟 { 或 , 的纯数字键」补一次引号再试；解析失败则抛出原始错误。
    """
    try:
        return json.loads(text)
    except json.JSONDecodeError as original:
        fixed = _BARE_KEY_RE.sub(r'\1"\2"\3', text)
        if fixed != text:
            try:
                data = json.loads(fixed)
                print('[*] 检测到配置里的端口键未加引号，已自动兼容；'
                      '建议写成 {"3389": 46234}', flush=True)
                return data
            except json.JSONDecodeError:
                pass
        raise original


def write_template(path):
    """生成配置模板：优先拷贝与脚本同目录捆绑的 config.json（brew 安装时打包的模板），
    否则用内置占位模板。"""
    path.parent.mkdir(parents=True, exist_ok=True)
    bundled = Path(__file__).resolve().with_name("config.json")
    if bundled.exists() and bundled.resolve() != path.resolve():
        shutil.copy(bundled, path)
    else:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(CONFIG_TEMPLATE, f, ensure_ascii=False, indent=4)
            f.write("\n")


def load_config(path):
    """读取并校验配置文件，返回「期望配置」对象。

    两种模式：
      - 自动模式 {"mode": "auto", "appkey", "overrides", 探测参数...}
          对象里没有 local_port 时按自动模式处理（一个 appkey 映射其名下全部映射）。
      - 兼容模式 {"mode": "legacy", "tasks": [task, ...]}
          数组 [{...}, {...}]，或带 local_port 的单个对象。

    某一项写错只跳过该项并打印原因，其余任务照常工作；
    若一个可用任务都没有（或文件本身不合法），抛 ValueError —— 守护模式据此等待修正。
    """
    with open(path, "r", encoding="utf-8") as f:
        raw = _loads_lenient(f.read())

    if isinstance(raw, dict) and "local_port" not in raw:
        return parse_auto_config(raw)
    if isinstance(raw, (dict, list)):
        return {"mode": "legacy", "tasks": _parse_legacy_tasks(
            [raw] if isinstance(raw, dict) else raw)}
    raise ValueError("配置内容必须是数组 [ {...} ] 或对象 {...}")


def _parse_legacy_tasks(items):
    """兼容模式：把任务数组逐项校验、去重"""
    tasks = []
    seen_port = {}
    for idx, item in enumerate(items, 1):
        try:
            task = parse_task(item, idx)
        except ValueError as e:
            print(f"[-] 配置第 {idx} 项无效，已跳过：{e}", flush=True)
            continue
        dup = seen_port.get(task["local_port"])
        if dup is not None:
            print(f"[-] 配置第 {idx} 项无效，已跳过：local_port={task['local_port']} "
                  f"与第 {dup} 项重复（同一端口不能监听两次）", flush=True)
            continue
        seen_port[task["local_port"]] = idx
        tasks.append(task)

    if not tasks:
        raise ValueError("没有任何可用的转发任务（请检查 appkey 与 local_port）")
    return tasks


def parse_auto_config(item):
    """自动模式：校验 {appkey, local_ports?}，返回期望配置。"""
    if not isinstance(item, dict):
        raise ValueError(f"应为对象 {{...}}，实际是 {type(item).__name__}")
    appkey = str(item.get("appkey") or "").strip()
    if not appkey:
        raise ValueError("缺少 appkey")
    if appkey == PLACEHOLDER_APPKEY:
        raise ValueError("appkey 尚未填写（请改成真实 appkey）")

    raw_ports = item.get("local_ports")
    if raw_ports in (None, ""):
        raw_ports = {}
    if not isinstance(raw_ports, dict):
        raise ValueError('local_ports 必须是对象，如 {"3389": 46234}'
                         '（键 = 本地监听端口，值 = 远端映射端口）')

    overrides = {}
    for raw_listen, raw_remote in raw_ports.items():
        try:
            listen = int(raw_listen)
        except (TypeError, ValueError):
            raise ValueError(f"local_ports 的键不是数字: {raw_listen!r}（应为本地监听端口）")
        try:
            remote = int(raw_remote)
        except (TypeError, ValueError):
            raise ValueError(f"local_ports 的值不是数字: {raw_remote!r}"
                             f"（应为远端映射端口，对应条目 {raw_listen}）")
        if not 0 < listen < 65536:
            raise ValueError(f"local_ports 的本地监听端口超出范围（1-65535）: {listen}")
        if not 0 < remote < 65536:
            raise ValueError(f"local_ports 的远端映射端口超出范围（1-65535）: {remote}")
        overrides[listen] = remote

    cfg = {"mode": "auto", "appkey": appkey, "overrides": overrides}
    cfg.update(_probe_params(item))
    return cfg


def parse_task(item, index):
    """解析并校验兼容模式下的单个转发任务；返回补齐默认值后的 dict"""
    if not isinstance(item, dict):
        raise ValueError(f"应为对象 {{...}}，实际是 {type(item).__name__}")
    appkey = str(item.get("appkey") or "").strip()
    if not appkey:
        raise ValueError("缺少 appkey")
    if appkey == PLACEHOLDER_APPKEY:
        raise ValueError("appkey 尚未填写（请改成真实 appkey）")
    if "local_port" not in item:
        raise ValueError("缺少 local_port")
    try:
        local_port = int(item["local_port"])
    except (TypeError, ValueError):
        raise ValueError(f"local_port 不是数字: {item['local_port']!r}")
    if not 0 < local_port < 65536:
        raise ValueError(f"local_port 超出范围（1-65535）: {local_port}")

    try:
        remote_local_port = int(item.get("remote_local_port") or 0)
    except (TypeError, ValueError):
        raise ValueError(f"remote_local_port 不是数字: {item['remote_local_port']!r}")
    if not 0 <= remote_local_port < 65536:
        raise ValueError(f"remote_local_port 超出范围（0-65535）: {remote_local_port}")

    try:
        lan_addr = parse_addr(item.get("remote_lan_addr"), remote_local_port)
    except ValueError as e:
        raise ValueError(f"remote_lan_addr {e}")

    task = {
        "index": index,
        "appkey": appkey,
        "local_port": local_port,
        "remote_local_port": remote_local_port,
        "remote_key": None,          # 兼容模式按 remote_local_port 定位映射
        "remote_lan_addr": lan_addr,
    }
    task.update(_probe_params(item))
    return task


def wait_config_ready(path):
    """守护模式：配置缺失则生成模板，并周期等待用户编辑到合法为止（返回期望配置）。"""
    if not path.exists():
        write_template(path)
        print(f"[+] 已生成配置模板: {path}", flush=True)
        print(f"[*] 请编辑该文件填入 appkey 后保存，客户端将自动继续"
              f"（每 {CONFIG_WAIT_INTERVAL} 秒检查一次）...", flush=True)
        print(f"[*] 填好 appkey 即可：客户端会自动把该 appkey 下的所有映射映射到本机；"
              f"想指定本地端口就用 local_ports。", flush=True)
    while True:
        try:
            return load_config(path)
        except FileNotFoundError:
            pass
        except (ValueError, json.JSONDecodeError) as e:
            print(f"[-] 配置尚未就绪: {e}，{CONFIG_WAIT_INTERVAL} 秒后重试...", flush=True)
        except OSError as e:
            print(f"[-] 配置文件读取失败: {e}，{CONFIG_WAIT_INTERVAL} 秒后重试...", flush=True)
        time.sleep(CONFIG_WAIT_INTERVAL)


def task_signature(cfg):
    """任务的关键参数指纹：变了就重启该任务，没变就让它继续跑（不打断已有转发）"""
    return (cfg["appkey"], cfg["local_port"], cfg["remote_local_port"],
            cfg.get("remote_key"), cfg["remote_lan_addr"],
            cfg["probe_interval"], cfg["probe_timeout"],
            cfg["lan_recheck_interval"])


def query_address(server_url, appkey, local_port=0):
    """查询server端映射地址。返回 (host, port)；未上线返回 None；appkey无效抛异常。"""
    params = {"appkey": appkey}
    if local_port:
        params["local_port"] = int(local_port)
    url = server_url.rstrip("/") + "/api/query/?" + urlencode(params)
    try:
        with urlopen(url, timeout=10) as resp:
            data = json.loads(resp.read().decode())
    except HTTPError as e:
        try:
            msg = json.loads(e.read().decode()).get("msg")
        except Exception:
            msg = f"HTTP {e.code}"
        raise RuntimeError(f"查询失败: {msg}")
    if not data.get("ok"):
        raise RuntimeError(data.get("msg", "未知错误"))
    if not data.get("online"):
        return None
    return (data["host"], int(data["port"]))


def query_mappings(server_url, appkey):
    """枚举该 appkey 名下的全部映射（含管理通道），返回 list[dict]"""
    url = server_url.rstrip("/") + "/api/mappings/?" + urlencode({"appkey": appkey})
    try:
        with urlopen(url, timeout=10) as resp:
            data = json.loads(resp.read().decode())
    except HTTPError as e:
        try:
            msg = json.loads(e.read().decode()).get("msg")
        except Exception:
            msg = f"HTTP {e.code}"
        raise RuntimeError(f"查询失败: {msg}")
    if not data.get("ok"):
        raise RuntimeError(data.get("msg", "未知错误"))
    return data.get("mappings") or []


def _mapping_addr(m):
    """从映射记录里取公网地址；未上线返回 None"""
    if m and m.get("online") and m.get("host") and m.get("port"):
        return (m["host"], int(m["port"]))
    return None


def make_resolver(appkey, remote_local_port=0, remote_key=None):
    """返回一个「无参可调用对象」，调用后给出当前转发目标 (host, port) 或 None。

    - 带 remote_key（自动模式）：按平台映射 id 精确定位，取该条映射最新的公网地址；
    - 不带（兼容模式）：按 remote_local_port 查询，等价旧版行为。
    """
    if remote_key:
        def _resolve():
            for m in query_mappings(SERVER_URL, appkey):
                if str(m.get("id")) == str(remote_key):
                    return _mapping_addr(m)
            return None
        return _resolve

    def _resolve():
        return query_address(SERVER_URL, appkey, remote_local_port)
    return _resolve


def resolve_quiet(resolve):
    """探测线程里用的静默解析：任何异常都返回 None，只打印日志"""
    try:
        return resolve()
    except (URLError, OSError) as e:
        print(f"[-] 查询server网络错误: {e}", flush=True)
    except RuntimeError as e:
        print(f"[-] {e}", flush=True)
    return None


def wait_for_address(resolve, poll_interval=POLL_INTERVAL, stop_event=None):
    """轮询直到拿到映射地址（customer-server 上线并上报后）。守护模式下永不退出。

    传入 stop_event 时，可在外部要求停止 —— 此时返回 None。
    """
    def _sleep(sec):
        """可被 stop_event 中断的等待；返回 True 表示应当退出"""
        if stop_event is None:
            time.sleep(sec)
            return False
        return stop_event.wait(sec)

    attempt = 0
    backoff = poll_interval
    while True:
        if stop_event is not None and stop_event.is_set():
            return None
        attempt += 1
        try:
            addr = resolve()
            backoff = poll_interval
        except (URLError, OSError) as e:
            print(f"[-] 第 {attempt} 次查询网络错误: {e}，{backoff} 秒后重试...", flush=True)
            if _sleep(backoff):
                return None
            backoff = min(backoff * 2, 60)
            continue
        except RuntimeError as e:
            print(f"[-] {e}，{backoff} 秒后重试...", flush=True)
            if _sleep(backoff):
                return None
            backoff = min(backoff * 2, 60)
            continue
        if addr:
            print(f"[+] 第 {attempt} 次查询: 获取到外部地址 {addr[0]}:{addr[1]}", flush=True)
            return addr
        print(f"[*] 第 {attempt} 次查询: 映射尚未上线，{poll_interval}秒后重试...", flush=True)
        if _sleep(poll_interval):
            return None


# ===================== 转发目标与可达性探测 =====================

class TargetHolder(object):
    """转发目标容器，可在运行中被探测线程安全地热切换。

    优先级：内网地址（若已配置且未被判定不可用）> 公网地址。
    """

    def __init__(self, lan_addr=None):
        self._lock = threading.Lock()
        self._lan = lan_addr
        self._wan = None
        self._prefer_lan = bool(lan_addr)

    def set_wan(self, addr):
        with self._lock:
            self._wan = addr

    def get_wan(self):
        with self._lock:
            return self._wan

    def get_lan(self):
        with self._lock:
            return self._lan

    def is_prefer_lan(self):
        with self._lock:
            return self._prefer_lan

    def drop_lan_pref(self):
        """内网不可达时调用：暂时放弃内网优先"""
        with self._lock:
            self._prefer_lan = False

    def restore_lan_pref(self):
        """内网恢复可达时调用：恢复内网优先"""
        with self._lock:
            self._prefer_lan = bool(self._lan)

    def current(self):
        """返回当前应使用的目标 (addr, source)，无可用目标时 addr 为 None"""
        with self._lock:
            if self._prefer_lan and self._lan:
                return self._lan, "lan"
            if self._wan:
                return self._wan, "wan"
            if self._lan:
                return self._lan, "lan"
            return None, "none"


def tcp_reachable(addr, timeout):
    """TCP 层可达性探测"""
    if not addr:
        return False
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(timeout)
    try:
        s.connect(addr)
        return True
    except OSError:
        return False
    finally:
        try:
            s.close()
        except Exception:
            pass


def probe_loop(holder, resolve, cfg, stop_event):
    """实时探测当前转发目标，并在不可达时重查平台上的公网地址是否变更。

    - 内网地址不可达 -> 放弃内网优先，改用公网地址
    - 公网地址不可达 -> 查询平台；地址变更则切换，未变更则判定异常并指数退避
    - 公网使用中时周期性回探内网，恢复可达则切回内网优先
    """
    interval = cfg["probe_interval"]
    timeout = cfg["probe_timeout"]
    lan_recheck = cfg["lan_recheck_interval"]
    fail_streak = 0
    last_lan_check = 0.0

    while not stop_event.is_set():
        # 尚未拿到公网地址时，先补一次
        if holder.get_wan() is None:
            addr = resolve_quiet(resolve)
            if addr:
                holder.set_wan(addr)
                print(f"[+] 从 server 获取到公网地址: {fmt_addr(addr)}", flush=True)
            else:
                stop_event.wait(interval)
                continue

        target, source = holder.current()
        if target and tcp_reachable(target, timeout):
            if fail_streak:
                print(f"[+] 转发目标恢复可达: {fmt_addr(target)}（{source}）", flush=True)
            fail_streak = 0
            # 正在走公网、且配置了内网地址时，周期回探内网
            lan = holder.get_lan()
            if source == "wan" and lan:
                tick = time.time()
                if tick - last_lan_check >= lan_recheck:
                    last_lan_check = tick
                    if tcp_reachable(lan, timeout):
                        print(f"[*] 内网地址 {fmt_addr(lan)} 恢复可达，切回内网优先直连", flush=True)
                        holder.restore_lan_pref()
            stop_event.wait(interval)
            continue

        # ---------- 不可达 ----------
        fail_streak += 1
        print(f"[-] 转发目标不可达: {fmt_addr(target)}（{source}），连续第 {fail_streak} 次", flush=True)

        if source == "lan":
            print("[*] 内网地址不可达，改用 server 上的公网地址", flush=True)
            holder.drop_lan_pref()
            stop_event.wait(min(interval, 3))
            continue

        # 公网不可达：向 server 查询地址是否变更
        old = holder.get_wan()
        new = resolve_quiet(resolve)
        if new is None:
            print("[-] server 未返回可用公网地址，稍后重试", flush=True)
        elif new != old:
            print(f"[*] 公网地址已变更 {fmt_addr(old)} -> {fmt_addr(new)}，切换转发目标", flush=True)
            holder.set_wan(new)
            stop_event.wait(min(interval, 3))
            continue
        else:
            print(f"[-] server 侧公网地址未变化（{fmt_addr(old)}），判定为异常，退避重试", flush=True)

        backoff = min(interval * (2 ** min(fail_streak, 4)), 60)
        stop_event.wait(backoff)


# ===================== 本地转发 =====================

def fwd(a, b):
    """双向转发的一侧"""
    try:
        while True:
            d = a.recv(65535)
            if not d:
                break
            b.sendall(d)
    except (OSError, BrokenPipeError, ConnectionResetError):
        pass


def handle(client_sock, client_addr, holder):
    """将本地连接转发到当前目标地址。

    每次连接都重新向 holder 取目标，因此探测线程切换地址后，新连接会自动走新地址。
    """
    target, source = holder.current()
    if not target:
        print(f"[{now()}] [-] {client_addr} 暂无可用转发目标，拒绝连接", flush=True)
        try:
            client_sock.close()
        except Exception:
            pass
        return

    remote = None
    try:
        remote = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        remote.settimeout(CONNECT_TIMEOUT)
        remote.connect(target)
        remote.settimeout(None)
        print(f"[{now()}] [+] 连接 {client_addr[0]}:{client_addr[1]} -> "
              f"{target[0]}:{target[1]}（{source}）", flush=True)
        t1 = threading.Thread(target=fwd, args=(client_sock, remote), daemon=True)
        t2 = threading.Thread(target=fwd, args=(remote, client_sock), daemon=True)
        t1.start(); t2.start()
        t1.join(); t2.join()
    except Exception as e:
        print(f"[{now()}] [-] {client_addr} 转发错误: {e}", flush=True)
    finally:
        for s in (client_sock, remote):
            if s:
                try:
                    s.close()
                except Exception:
                    pass


def accept_loop(listen_sock, holder, stop_event=None):
    while True:
        if stop_event is not None and stop_event.is_set():
            return
        try:
            readable, _, _ = select.select([listen_sock], [], [], 1.0)
            if not readable:
                continue
            cs, ca = listen_sock.accept()
            threading.Thread(target=handle, args=(cs, ca, holder), daemon=True).start()
        except OSError as e:
            if e.errno == 9:  # EBADF
                break
        except Exception:
            pass


def _run_task_once(cfg, stop_event):
    """跑一轮转发任务：确定初始目标 -> 本地监听 -> 后台探测 + 转发循环。

    监听失败 / 转发循环异常时抛出，由 run_task 退避重试；stop_event 被置位则尽快返回。
    """
    appkey = cfg["appkey"]
    local_port = cfg["local_port"]
    lan = cfg["remote_lan_addr"]
    remote_lp = cfg["remote_local_port"]

    print(f"[*] 任务启动: 本地 127.0.0.1:{local_port} -> 平台={SERVER_URL} "
          f"appkey={appkey} 远端映射端口={remote_lp or '未指定'} 内网地址={fmt_addr(lan)}",
          flush=True)

    resolve = make_resolver(appkey, remote_lp, cfg.get("remote_key"))
    holder = TargetHolder(lan)

    # 1. 确定初始转发目标：内网可达就不必等公网，否则等 customer-server 上报
    if lan and tcp_reachable(lan, cfg["probe_timeout"]):
        print(f"[+] 内网地址 {fmt_addr(lan)} 可达，优先直连；公网地址由后台探测线程获取", flush=True)
    else:
        if lan:
            print(f"[-] 内网地址 {fmt_addr(lan)} 不可达，等待平台上的公网地址...", flush=True)
        wan = wait_for_address(resolve, stop_event=stop_event)
        if wan is None:
            return                      # 被要求停止
        holder.set_wan(wan)

    if stop_event.is_set():
        return

    # 2. 本地监听
    listen_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    listen_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        listen_sock.bind(("127.0.0.1", local_port))
        listen_sock.listen(65535)
    except OSError as e:
        try:
            listen_sock.close()
        except Exception:
            pass
        raise RuntimeError(f"本地端口 {local_port} 监听失败: {e}")
    print(f"[+] 本地监听: 127.0.0.1:{local_port}", flush=True)
    target, source = holder.current()
    print(f"[+] 当前转发目标（{source}）: {fmt_addr(target)}", flush=True)

    # 3. 可达性探测线程
    threading.Thread(target=probe_loop,
                     args=(holder, resolve, cfg, stop_event),
                     daemon=True, name=f"probe-{local_port}").start()

    # 4. 转发循环（异常向上抛，由 run_task 退避重试）
    try:
        accept_loop(listen_sock, holder, stop_event=stop_event)
    finally:
        stop_event.set()
        try:
            listen_sock.close()      # 端口随线程退出立即释放
        except Exception:
            pass


def run_task(cfg, stop_event):
    """单个转发任务的生命周期：出错退避重试，直到被要求停止（不影响其他任务）。

    任务参数的热更新由 run_daemon 的调度器负责 —— 配置变了就停掉本线程、按新参数重启。
    """
    while not stop_event.is_set():
        try:
            _run_task_once(cfg, stop_event)
        except Exception as e:
            print(f"[-] 任务（本地端口 {cfg['local_port']}）异常: {e}", flush=True)
        if stop_event.wait(TASK_RETRY_INTERVAL):
            return
        print(f"[*] 任务（本地端口 {cfg['local_port']}）重试中...", flush=True)


# ===================== 自动模式：枚举映射 -> 生成任务 =====================

def discover_tasks(cfg, warn_state=None):
    """按「一个 appkey」向平台枚举全部映射，生成转发任务列表。

    本地监听端口的确定规则：
      1. 若 local_ports 指定了「远端端口 -> 本地端口」（即某条 overrides 的值等于该
         映射的远端端口），用指定的本地端口；
      2. 否则默认用该映射的远端端口（remote_local_port）；远端端口未知（0）时
         退而使用它的公网端口。
    同一本地端口被多条映射占用时，显式指定的那条优先，其余跳过并告警。
    """
    appkey = cfg["appkey"]
    overrides = cfg["overrides"]                 # {本地监听端口: 远端映射端口}
    mappings = query_mappings(SERVER_URL, appkey)

    # 远端映射端口 -> 期望的本地监听端口（显式指定）
    reverse = {}
    for listen, remote in overrides.items():
        if remote in reverse and reverse[remote] != listen:
            print(f"[-] local_ports 中 {listen}: {remote} 与 "
                  f"{reverse[remote]}: {remote} 指向同一条映射，已忽略前者", flush=True)
        reverse[remote] = listen

    matched = set()
    rows = []                                    # (本地端口, 是否显式指定, 远端端口, 映射)
    for m in mappings:
        if m.get("is_management"):
            continue                             # 管理通道是设备自己的控制入口，不转发
        try:
            remote_lp = int(m.get("local_port") or 0)
        except (TypeError, ValueError):
            remote_lp = 0
        try:
            public_port = int(m.get("port") or 0)
        except (TypeError, ValueError):
            public_port = 0

        if remote_lp and remote_lp in reverse:
            listen, is_override = reverse[remote_lp], True
        else:
            listen, is_override = (remote_lp or public_port), False

        if not 0 < listen < 65536:
            print(f"[-] 映射「{m.get('name') or m.get('id')}」无法确定本地监听端口"
                  f"（远端端口={remote_lp}，公网端口={public_port}），已跳过；"
                  f"可用 local_ports 指定", flush=True)
            continue
        if is_override:
            matched.add(remote_lp)
        rows.append((listen, is_override, remote_lp, m))

    # 显式指定的优先占位；同端口冲突时后者让位
    rows.sort(key=lambda r: (0 if r[1] else 1, r[0]))
    chosen = {}
    for listen, is_override, remote_lp, m in rows:
        if listen in chosen:
            print(f"[-] 本地端口 {listen} 被多条映射占用："
                  f"远端 {chosen[listen][0]}（保留）、远端 {remote_lp}（跳过）。"
                  f"可用 local_ports 指定不同端口", flush=True)
            continue
        chosen[listen] = (remote_lp, m)

    tasks = []
    for listen in sorted(chosen):
        remote_lp, m = chosen[listen]
        key = m.get("id", m.get("key"))
        task = {
            "index": 0,
            "appkey": appkey,
            "local_port": listen,
            "remote_local_port": remote_lp,
            "remote_key": str(key) if key is not None else None,
            "remote_lan_addr": None,
        }
        task.update(_probe_params(cfg))
        tasks.append(task)

    # local_ports 里没匹配上任何映射的项：提示一次（避免每轮都刷屏）
    unmatched = sorted((l, r) for l, r in overrides.items() if r not in matched)
    if warn_state is not None and tuple(unmatched) != warn_state.get("unmatched"):
        warn_state["unmatched"] = tuple(unmatched)
        for listen, remote in unmatched:
            print(f"[*] local_ports 中的 {listen}: {remote} 暂未匹配到映射"
                  f"（该 appkey 下没有远端端口为 {remote} 的映射）", flush=True)
    return tasks


# ===================== 守护模式 =====================

def reconcile(running, tasks):
    """把运行中的任务收敛到 tasks 这个「期望集合」（按本地监听端口对齐）。"""
    want = {t["local_port"]: t for t in tasks}
    # a) 停掉「已不再需要」或「参数已变」的任务（先停干净再起，避免端口冲突）
    for port in list(running):
        ent = running[port]
        if port in want and task_signature(ent["task"]) == task_signature(want[port]):
            continue
        ent["stop"].set()
        ent["thread"].join(timeout=5)
        running.pop(port)
        print(f"[*] 任务 127.0.0.1:{port} "
              f"{'参数已变更，重启' if port in want else '已不再需要，停止'}", flush=True)
    # b) 启动新任务 / 重启已退出的任务
    for port, task in want.items():
        ent = running.get(port)
        if ent and ent["thread"].is_alive():
            continue
        if ent:
            print(f"[*] 任务 127.0.0.1:{port} 已退出，重新启动", flush=True)
        stop_event = threading.Event()
        th = threading.Thread(target=run_task, args=(task, stop_event),
                              daemon=True, name=f"fwd-{port}")
        th.start()
        running[port] = {"task": task, "sig": task_signature(task),
                         "stop": stop_event, "thread": th}
        if not ent:
            print(f"[+] 已启动转发任务: 127.0.0.1:{port} "
                  f"-> 远端映射端口 {task['remote_local_port'] or '最近一条'}", flush=True)


def run_daemon(config_path):
    """守护模式：持续把「期望状态」收敛成实际运行的任务 —— 增 / 删 / 改都不用重启服务。

    - 兼容模式：期望状态来自配置文件（数组里的每个任务）
    - 自动模式：期望状态 = 该 appkey 在平台上的全部映射（按 local_ports 覆盖本地端口），
      周期性重新枚举，映射增减会自动反映到本地监听上
    - 每个转发任务一个线程，单个任务出错只影响它自己
    - 配置文件暂时写坏（正在编辑 / 语法错）时保留现有任务继续转发，只打印告警
    """
    cfg = wait_config_ready(config_path)     # 首次启动：等到有一份可用配置
    running = {}                             # local_port -> {"task", "sig", "stop", "thread"}
    last_error = None
    desired = None                           # 当前期望任务列表
    warn_state = {}
    auto_appkey = None
    next_discover = 0.0

    while True:
        try:
            cfg = load_config(config_path)
            if last_error is not None:
                print("[+] 配置已恢复可用", flush=True)
            last_error = None
        except (ValueError, json.JSONDecodeError, OSError) as e:
            cfg = None
            if str(e) != last_error:
                last_error = str(e)
                print(f"[-] 配置暂不可用（保留现有任务继续转发）: {e}", flush=True)

        if cfg is not None:
            if cfg["mode"] == "legacy":
                desired = cfg["tasks"]
            else:
                # 自动模式：换了 appkey 就重置，之后按 DISCOVER_INTERVAL 周期枚举
                if cfg["appkey"] != auto_appkey:
                    auto_appkey = cfg["appkey"]
                    desired = None
                    warn_state = {}
                    next_discover = 0.0
                now_ts = time.time()
                if now_ts >= next_discover:
                    next_discover = now_ts + DISCOVER_INTERVAL
                    try:
                        desired = discover_tasks(cfg, warn_state)
                    except (URLError, OSError, RuntimeError) as e:
                        print(f"[-] 获取映射列表失败（沿用上次结果）: {e}", flush=True)

        if desired is not None:
            reconcile(running, desired)

        time.sleep(DAEMON_TICK)


def main():
    parser = argparse.ArgumentParser(
        description="xfeichong 客户端：本地TCP转发到NAT映射地址",
        epilog="brew services 管理示例: brew services start xfeichong-client")
    parser.add_argument("command", nargs="?", choices=["init"], default=None,
                        help="init = 仅生成配置模板并退出（默认为守护模式）")
    parser.add_argument("--config", "-c", default=str(DEFAULT_CONFIG),
                        help=f"配置文件路径（默认 {DEFAULT_CONFIG}）")
    args = parser.parse_args()
    config_path = Path(os.path.expanduser(args.config))

    if args.command == "init":
        if config_path.exists():
            print(f"[*] 配置文件已存在，不覆盖: {config_path}")
        else:
            write_template(config_path)
            print(f"[+] 已生成配置模板: {config_path}")
            print(f"[*] 填好 appkey 即可（客户端会自动映射该 appkey 下的所有映射）；"
                  f"想指定本地端口，就在 local_ports 里写 "
                  f'{{"3389": 46234}}（把远端 46234 映射到本地 3389）。')
            print(f"[*] 然后运行: xfeichong-client（或 brew services start xfeichong-client）")
        return

    run_daemon(config_path)


if __name__ == "__main__":
    main()
