#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
natmap_client.py - macOS 客户端本地TCP转发脚本

用法:
    xfeichong-client                 # 守护模式（brew services / launchd 托管）
    xfeichong-client init            # 仅生成配置模板 ~/.xfeichong/config.json
    xfeichong-client -c /path/cfg    # 指定配置文件路径

配置文件（~/.xfeichong/config.json）是一个「转发任务数组」，一个客户端可以同时
配置多个映射转发，每个任务独占一个线程、互不影响：

    [
      {"appkey": "XXXX", "local_port": 8889, "remote_local_port": 4674},
      {"appkey": "XXXX", "local_port": 8890, "remote_local_port": 4675}
    ]

每个任务做的事:
    1. 本地监听 127.0.0.1:local_port
    2. 转发目标优先级: 配置的「远程服务器内网地址(remote_lan_addr)」> 平台查到的「公网映射地址」
    3. 后台探测线程实时探测当前目标是否可达:
       - 内网地址不可达        -> 立即改用平台上的公网地址
       - 公网地址不可达        -> 重新向平台查询，地址有变更则切换并重试
       - 换了地址仍然不可达    -> 判定为异常，指数退避后继续重试
       - 内网地址恢复可达      -> 自动切回内网优先直连

平台地址写死在程序里（DEFAULT_SERVER_URL），配置文件里不再需要 server_url；
本地联调可用环境变量 XFEICHONG_SERVER_URL 临时覆盖。

守护模式设计（供 brew services 常驻）:
    - 任何错误（配置未就绪/平台暂时不可达/appkey 未上线）都退避重试，不退出进程
    - 单个任务出错只影响该任务，其余任务继续工作
    - 日志输出到 stdout，由 launchd 重定向到 Homebrew 日志文件
"""

import argparse
import json
import os
import shutil
import socket
import select
import threading
import time
import sys
from pathlib import Path
from urllib.request import urlopen
from urllib.parse import urlencode
from urllib.error import HTTPError, URLError

# ===================== 默认配置 =====================
CONFIG_DIR = Path.home() / ".xfeichong"
DEFAULT_CONFIG = CONFIG_DIR / "config.json"
# 平台地址写死在程序里（配置文件不再提供该项）。
# 仅本地联调需要指到别的地址时，用环境变量临时覆盖：XFEICHONG_SERVER_URL=http://127.0.0.1:8000
DEFAULT_SERVER_URL = "https://xfeichong.com"
SERVER_URL = os.environ.get("XFEICHONG_SERVER_URL", "").strip() or DEFAULT_SERVER_URL
POLL_INTERVAL = 5          # 轮询server的间隔（秒）
CONNECT_TIMEOUT = 10       # 转发连接超时（秒）
CONFIG_WAIT_INTERVAL = 30  # 守护模式下配置模板生成后等待编辑的检查间隔（秒）
PROBE_INTERVAL = 10        # 可达性探测间隔（秒）
PROBE_TIMEOUT = 3          # 单次可达性探测超时（秒）
LAN_RECHECK_INTERVAL = 60  # 已切到公网后，回探内网地址的间隔（秒）
TASK_RETRY_INTERVAL = 30   # 单个转发任务异常后的重试间隔（秒）
PLACEHOLDER_APPKEY = "你的APPKEY"

# 配置模板：数组，每个元素是一个独立的「本地端口 -> 远端映射」转发任务。
# 需要多转发几条，就往数组里再加一个对象；某项配置写错只会跳过该项，不影响其他任务。
CONFIG_TEMPLATE = [
    {
        "appkey": PLACEHOLDER_APPKEY,
        # 本地监听端口（127.0.0.1:local_port）
        "local_port": 8889,
        # 远端映射的 local_port（远端设备上那条映射的本地端口），用于精确查询它的公网地址；
        # 0 或不填 = 用该 appkey 最近上报的一条映射
        "remote_local_port": 4674,
        # 远端服务器的内网地址（可选，格式 "主机:端口"）。与远端处于同一局域网时填它可
        # 优先直连内网（更快、不占用上行带宽）；留空则只使用平台查到的公网地址。
        "remote_lan_addr": "",
        # 以下三项是探测参数，一般不用改：
        "probe_interval": PROBE_INTERVAL,              # 可达性探测间隔（秒）
        "probe_timeout": PROBE_TIMEOUT,                # 单次探测超时（秒）
        "lan_recheck_interval": LAN_RECHECK_INTERVAL,  # 走公网后回探内网的间隔（秒）
    },
]
# ====================================================


def now():
    return time.strftime('%H:%M:%S')


def fmt_addr(addr):
    return f"{addr[0]}:{addr[1]}" if addr else "无"


def parse_addr(value, default_port=0):
    """把 "host:port" 解析成 (host, port)；端口可省略（用 default_port 兜底）"""
    if not value:
        return None
    text = str(value).strip()
    if not text:
        return None
    if ":" in text:
        host, _, port_text = text.rpartition(":")
        host = host.strip()
        try:
            port = int(port_text)
        except ValueError:
            raise ValueError(f"地址格式错误: {value}（应为 主机:端口）")
    else:
        host, port = text, int(default_port or 0)
    if not host:
        raise ValueError(f"地址格式错误: {value}（主机为空）")
    if not 0 < port < 65536:
        raise ValueError(f"地址格式错误: {value}（端口无效，可填写 remote_local_port 兜底）")
    return (host, port)


def write_template(path):
    """生成配置模板：优先拷贝与脚本同目录捆绑的 config.json（brew 安装时打包的模板），
    否则用内置占位模板。"""
    path.parent.mkdir(parents=True, exist_ok=True)
    bundled = Path(__file__).resolve().with_name("config.json")
    if bundled.exists() and bundled.resolve() != path.resolve():
        shutil.copy(bundled, path)
    else:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(CONFIG_TEMPLATE, f, ensure_ascii=False, indent=4)
            f.write("\n")


def load_config(path):
    """读取并校验配置文件，返回「转发任务数组」（每项一个 dict）。

    兼容两种写法：
      - 数组： [{...}, {...}]   ← 推荐，一个客户端配多个映射转发
      - 对象： {...}            ← 旧格式，等价于只有一个任务的数组

    某一项写错只跳过该项并打印原因，其余任务照常工作；
    若一个可用任务都没有（或文件本身不合法），抛 ValueError —— 守护模式据此等待修正。
    """
    with open(path, "r", encoding="utf-8") as f:
        raw = json.load(f)
    items = normalize_tasks(raw)

    tasks = []
    seen_port = {}
    for idx, item in enumerate(items, 1):
        try:
            task = parse_task(item, idx)
        except ValueError as e:
            print(f"[-] 配置第 {idx} 项无效，已跳过：{e}", flush=True)
            continue
        dup = seen_port.get(task["local_port"])
        if dup is not None:
            print(f"[-] 配置第 {idx} 项无效，已跳过：local_port={task['local_port']} "
                  f"与第 {dup} 项重复（同一端口不能监听两次）", flush=True)
            continue
        seen_port[task["local_port"]] = idx
        tasks.append(task)

    if not tasks:
        raise ValueError("没有任何可用的转发任务（请检查 appkey 与 local_port）")
    return tasks


def normalize_tasks(raw):
    """把配置文件内容规整成任务数组（兼容旧的「单个对象」写法）"""
    if isinstance(raw, dict):
        return [raw]
    if isinstance(raw, list):
        return raw
    raise ValueError("配置内容必须是数组 [ {...}, {...} ] 或单个对象 {...}")


def parse_task(item, index):
    """解析并校验单个转发任务；返回补齐默认值后的 dict"""
    if not isinstance(item, dict):
        raise ValueError(f"应为对象 {{...}}，实际是 {type(item).__name__}")
    appkey = str(item.get("appkey") or "").strip()
    if not appkey:
        raise ValueError("缺少 appkey")
    if appkey == PLACEHOLDER_APPKEY:
        raise ValueError("appkey 尚未填写（请改成真实 appkey）")
    if "local_port" not in item:
        raise ValueError("缺少 local_port")
    try:
        local_port = int(item["local_port"])
    except (TypeError, ValueError):
        raise ValueError(f"local_port 不是数字: {item['local_port']!r}")
    if not 0 < local_port < 65536:
        raise ValueError(f"local_port 超出范围（1-65535）: {local_port}")

    try:
        remote_local_port = int(item.get("remote_local_port") or 0)
    except (TypeError, ValueError):
        raise ValueError(f"remote_local_port 不是数字: {item['remote_local_port']!r}")
    if not 0 <= remote_local_port < 65536:
        raise ValueError(f"remote_local_port 超出范围（0-65535）: {remote_local_port}")

    try:
        lan_addr = parse_addr(item.get("remote_lan_addr"), remote_local_port)
    except ValueError as e:
        raise ValueError(f"remote_lan_addr {e}")

    def _positive_int(key, default):
        value = item.get(key)
        try:
            value = int(value) if value not in (None, "") else default
        except (TypeError, ValueError):
            raise ValueError(f"{key} 不是数字: {item.get(key)!r}")
        if value <= 0:
            raise ValueError(f"{key} 必须大于 0: {value}")
        return value

    return {
        "index": index,
        "appkey": appkey,
        "local_port": local_port,
        "remote_local_port": remote_local_port,
        "remote_lan_addr": lan_addr,
        "probe_interval": _positive_int("probe_interval", PROBE_INTERVAL),
        "probe_timeout": _positive_int("probe_timeout", PROBE_TIMEOUT),
        "lan_recheck_interval": _positive_int("lan_recheck_interval", LAN_RECHECK_INTERVAL),
    }


def wait_config_ready(path):
    """守护模式：配置缺失则生成模板，并周期等待用户编辑到合法为止（返回任务数组）。"""
    if not path.exists():
        write_template(path)
        print(f"[+] 已生成配置模板: {path}", flush=True)
        print(f"[*] 请编辑该文件填入 appkey 后保存，客户端将自动继续"
              f"（每 {CONFIG_WAIT_INTERVAL} 秒检查一次）...", flush=True)
        print(f"[*] 模板是一个数组，一个客户端可以配置多个转发任务；"
              f"加一条就往数组里再放一个对象。", flush=True)
    while True:
        try:
            return load_config(path)
        except FileNotFoundError:
            pass
        except (ValueError, json.JSONDecodeError) as e:
            print(f"[-] 配置尚未就绪: {e}，{CONFIG_WAIT_INTERVAL} 秒后重试...", flush=True)
        except OSError as e:
            print(f"[-] 配置文件读取失败: {e}，{CONFIG_WAIT_INTERVAL} 秒后重试...", flush=True)
        time.sleep(CONFIG_WAIT_INTERVAL)


def task_signature(cfg):
    """任务的关键参数指纹：变了就重启该任务，没变就让它继续跑（不打断已有转发）"""
    return (cfg["appkey"], cfg["local_port"], cfg["remote_local_port"],
            cfg["remote_lan_addr"], cfg["probe_interval"], cfg["probe_timeout"],
            cfg["lan_recheck_interval"])


def query_address(server_url, appkey, local_port=0):
    """查询server端映射地址。返回 (host, port)；未上线返回 None；appkey无效抛异常。"""
    params = {"appkey": appkey}
    if local_port:
        params["local_port"] = int(local_port)
    url = server_url.rstrip("/") + "/api/query/?" + urlencode(params)
    try:
        with urlopen(url, timeout=10) as resp:
            data = json.loads(resp.read().decode())
    except HTTPError as e:
        try:
            msg = json.loads(e.read().decode()).get("msg")
        except Exception:
            msg = f"HTTP {e.code}"
        raise RuntimeError(f"查询失败: {msg}")
    if not data.get("ok"):
        raise RuntimeError(data.get("msg", "未知错误"))
    if not data.get("online"):
        return None
    return (data["host"], int(data["port"]))


def query_address_quiet(server_url, appkey, local_port=0):
    """探测线程里用的静默查询：任何异常都返回 None，只打印日志"""
    try:
        return query_address(server_url, appkey, local_port)
    except (URLError, OSError) as e:
        print(f"[-] 查询server网络错误: {e}", flush=True)
    except RuntimeError as e:
        print(f"[-] {e}", flush=True)
    return None


def wait_for_address(server_url, appkey, local_port=0, poll_interval=POLL_INTERVAL,
                     stop_event=None):
    """轮询直到拿到映射地址（customer-server 上线并上报后）。守护模式下永不退出。

    传入 stop_event 时，可在外部要求停止 —— 此时返回 None。
    """
    def _sleep(sec):
        """可被 stop_event 中断的等待；返回 True 表示应当退出"""
        if stop_event is None:
            time.sleep(sec)
            return False
        return stop_event.wait(sec)

    attempt = 0
    backoff = poll_interval
    while True:
        if stop_event is not None and stop_event.is_set():
            return None
        attempt += 1
        try:
            addr = query_address(server_url, appkey, local_port)
            backoff = poll_interval
        except (URLError, OSError) as e:
            print(f"[-] 第 {attempt} 次查询网络错误: {e}，{backoff} 秒后重试...", flush=True)
            if _sleep(backoff):
                return None
            backoff = min(backoff * 2, 60)
            continue
        except RuntimeError as e:
            print(f"[-] {e}，{backoff} 秒后重试...", flush=True)
            if _sleep(backoff):
                return None
            backoff = min(backoff * 2, 60)
            continue
        if addr:
            print(f"[+] 第 {attempt} 次查询: 获取到外部地址 {addr[0]}:{addr[1]}", flush=True)
            return addr
        print(f"[*] 第 {attempt} 次查询: customer-server 尚未上线，{poll_interval}秒后重试...", flush=True)
        if _sleep(poll_interval):
            return None


# ===================== 转发目标与可达性探测 =====================

class TargetHolder(object):
    """转发目标容器，可在运行中被探测线程安全地热切换。

    优先级：内网地址（若已配置且未被判定不可用）> 公网地址。
    """

    def __init__(self, lan_addr=None):
        self._lock = threading.Lock()
        self._lan = lan_addr
        self._wan = None
        self._prefer_lan = bool(lan_addr)

    def set_wan(self, addr):
        with self._lock:
            self._wan = addr

    def get_wan(self):
        with self._lock:
            return self._wan

    def get_lan(self):
        with self._lock:
            return self._lan

    def is_prefer_lan(self):
        with self._lock:
            return self._prefer_lan

    def drop_lan_pref(self):
        """内网不可达时调用：暂时放弃内网优先"""
        with self._lock:
            self._prefer_lan = False

    def restore_lan_pref(self):
        """内网恢复可达时调用：恢复内网优先"""
        with self._lock:
            self._prefer_lan = bool(self._lan)

    def current(self):
        """返回当前应使用的目标 (addr, source)，无可用目标时 addr 为 None"""
        with self._lock:
            if self._prefer_lan and self._lan:
                return self._lan, "lan"
            if self._wan:
                return self._wan, "wan"
            if self._lan:
                return self._lan, "lan"
            return None, "none"


def tcp_reachable(addr, timeout):
    """TCP 层可达性探测"""
    if not addr:
        return False
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(timeout)
    try:
        s.connect(addr)
        return True
    except OSError:
        return False
    finally:
        try:
            s.close()
        except Exception:
            pass


def probe_loop(holder, server_url, appkey, cfg, stop_event):
    """实时探测当前转发目标，并在不可达时向 server 查询公网地址是否变更。

    - 内网地址不可达 -> 放弃内网优先，改用公网地址
    - 公网地址不可达 -> 查询 server；地址变更则切换，未变更则判定异常并指数退避
    - 公网使用中时周期性回探内网，恢复可达则切回内网优先
    """
    interval = cfg["probe_interval"]
    timeout = cfg["probe_timeout"]
    lan_recheck = cfg["lan_recheck_interval"]
    remote_local_port = cfg["remote_local_port"]
    fail_streak = 0
    last_lan_check = 0.0

    while not stop_event.is_set():
        # 尚未拿到公网地址时，先补一次
        if holder.get_wan() is None:
            addr = query_address_quiet(server_url, appkey, remote_local_port)
            if addr:
                holder.set_wan(addr)
                print(f"[+] 从 server 获取到公网地址: {fmt_addr(addr)}", flush=True)
            else:
                stop_event.wait(interval)
                continue

        target, source = holder.current()
        if target and tcp_reachable(target, timeout):
            if fail_streak:
                print(f"[+] 转发目标恢复可达: {fmt_addr(target)}（{source}）", flush=True)
            fail_streak = 0
            # 正在走公网、且配置了内网地址时，周期回探内网
            lan = holder.get_lan()
            if source == "wan" and lan:
                tick = time.time()
                if tick - last_lan_check >= lan_recheck:
                    last_lan_check = tick
                    if tcp_reachable(lan, timeout):
                        print(f"[*] 内网地址 {fmt_addr(lan)} 恢复可达，切回内网优先直连", flush=True)
                        holder.restore_lan_pref()
            stop_event.wait(interval)
            continue

        # ---------- 不可达 ----------
        fail_streak += 1
        print(f"[-] 转发目标不可达: {fmt_addr(target)}（{source}），连续第 {fail_streak} 次", flush=True)

        if source == "lan":
            print("[*] 内网地址不可达，改用 server 上的公网地址", flush=True)
            holder.drop_lan_pref()
            stop_event.wait(min(interval, 3))
            continue

        # 公网不可达：向 server 查询地址是否变更
        old = holder.get_wan()
        new = query_address_quiet(server_url, appkey, remote_local_port)
        if new is None:
            print("[-] server 未返回可用公网地址，稍后重试", flush=True)
        elif new != old:
            print(f"[*] 公网地址已变更 {fmt_addr(old)} -> {fmt_addr(new)}，切换转发目标", flush=True)
            holder.set_wan(new)
            stop_event.wait(min(interval, 3))
            continue
        else:
            print(f"[-] server 侧公网地址未变化（{fmt_addr(old)}），判定为异常，退避重试", flush=True)

        backoff = min(interval * (2 ** min(fail_streak, 4)), 60)
        stop_event.wait(backoff)


# ===================== 本地转发 =====================

def fwd(a, b):
    """双向转发的一侧"""
    try:
        while True:
            d = a.recv(65535)
            if not d:
                break
            b.sendall(d)
    except (OSError, BrokenPipeError, ConnectionResetError):
        pass


def handle(client_sock, client_addr, holder):
    """将本地连接转发到当前目标地址。

    每次连接都重新向 holder 取目标，因此探测线程切换地址后，新连接会自动走新地址。
    """
    target, source = holder.current()
    if not target:
        print(f"[{now()}] [-] {client_addr} 暂无可用转发目标，拒绝连接", flush=True)
        try:
            client_sock.close()
        except Exception:
            pass
        return

    remote = None
    try:
        remote = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        remote.settimeout(CONNECT_TIMEOUT)
        remote.connect(target)
        remote.settimeout(None)
        print(f"[{now()}] [+] 连接 {client_addr[0]}:{client_addr[1]} -> "
              f"{target[0]}:{target[1]}（{source}）", flush=True)
        t1 = threading.Thread(target=fwd, args=(client_sock, remote), daemon=True)
        t2 = threading.Thread(target=fwd, args=(remote, client_sock), daemon=True)
        t1.start(); t2.start()
        t1.join(); t2.join()
    except Exception as e:
        print(f"[{now()}] [-] {client_addr} 转发错误: {e}", flush=True)
    finally:
        for s in (client_sock, remote):
            if s:
                try:
                    s.close()
                except Exception:
                    pass


def accept_loop(listen_sock, holder, stop_event=None):
    while True:
        if stop_event is not None and stop_event.is_set():
            return
        try:
            readable, _, _ = select.select([listen_sock], [], [], 1.0)
            if not readable:
                continue
            cs, ca = listen_sock.accept()
            threading.Thread(target=handle, args=(cs, ca, holder), daemon=True).start()
        except OSError as e:
            if e.errno == 9:  # EBADF
                break
        except Exception:
            pass


def _run_task_once(cfg, stop_event):
    """跑一轮转发任务：确定初始目标 -> 本地监听 -> 后台探测 + 转发循环。

    监听失败 / 转发循环异常时抛出，由 run_task 退避重试；stop_event 被置位则尽快返回。
    """
    server_url = SERVER_URL
    appkey = cfg["appkey"]
    local_port = cfg["local_port"]
    lan = cfg["remote_lan_addr"]
    remote_lp = cfg["remote_local_port"]

    print(f"[*] 任务启动: 本地 127.0.0.1:{local_port} -> 平台={server_url} "
          f"appkey={appkey} 远端映射端口={remote_lp or '未指定'} 内网地址={fmt_addr(lan)}",
          flush=True)

    holder = TargetHolder(lan)

    # 1. 确定初始转发目标：内网可达就不必等公网，否则等 customer-server 上报
    if lan and tcp_reachable(lan, cfg["probe_timeout"]):
        print(f"[+] 内网地址 {fmt_addr(lan)} 可达，优先直连；公网地址由后台探测线程获取", flush=True)
    else:
        if lan:
            print(f"[-] 内网地址 {fmt_addr(lan)} 不可达，等待平台上的公网地址...", flush=True)
        wan = wait_for_address(server_url, appkey, remote_lp, stop_event=stop_event)
        if wan is None:
            return                      # 被要求停止
        holder.set_wan(wan)

    if stop_event.is_set():
        return

    # 2. 本地监听
    listen_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    listen_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        listen_sock.bind(("127.0.0.1", local_port))
        listen_sock.listen(65535)
    except OSError as e:
        try:
            listen_sock.close()
        except Exception:
            pass
        raise RuntimeError(f"本地端口 {local_port} 监听失败: {e}")
    print(f"[+] 本地监听: 127.0.0.1:{local_port}", flush=True)
    target, source = holder.current()
    print(f"[+] 当前转发目标（{source}）: {fmt_addr(target)}", flush=True)

    # 3. 可达性探测线程
    threading.Thread(target=probe_loop,
                     args=(holder, server_url, appkey, cfg, stop_event),
                     daemon=True, name=f"probe-{local_port}").start()

    # 4. 转发循环（异常向上抛，由 run_task 退避重试）
    try:
        accept_loop(listen_sock, holder, stop_event=stop_event)
    finally:
        stop_event.set()
        try:
            listen_sock.close()      # 端口随线程退出立即释放
        except Exception:
            pass


def run_task(cfg, stop_event):
    """单个转发任务的生命周期：出错退避重试，直到被要求停止（不影响其他任务）。

    任务参数的热更新由 run_daemon 的调度器负责 —— 配置变了就停掉本线程、按新参数重启。
    """
    while not stop_event.is_set():
        try:
            _run_task_once(cfg, stop_event)
        except Exception as e:
            print(f"[-] 任务（本地端口 {cfg['local_port']}）异常: {e}", flush=True)
        if stop_event.wait(TASK_RETRY_INTERVAL):
            return
        print(f"[*] 任务（本地端口 {cfg['local_port']}）重试中...", flush=True)


def run_daemon(config_path):
    """守护模式：把配置文件当「期望状态」，持续收敛 —— 增 / 删 / 改任务都不用重启服务。

    - 每个转发任务一个线程，单个任务出错只影响它自己
    - 每 2 秒重读一次配置：新增的任务启动、删掉或改了的任务停掉重启、没动的继续跑
    - 配置文件暂时写坏（正在编辑 / 语法错）时保留现有任务继续转发，只打印告警
    """
    wait_config_ready(config_path)      # 首次启动：等到有一份可用配置（缺失则先生成模板）
    running = {}                        # local_port -> {"task", "sig", "stop", "thread"}
    last_error = None

    while True:
        try:
            tasks = load_config(config_path)
            last_error = None
        except (ValueError, json.JSONDecodeError, OSError) as e:
            tasks = None
            if str(e) != last_error:
                last_error = str(e)
                print(f"[-] 配置暂不可用（保留现有任务继续转发）: {e}", flush=True)

        if tasks is not None:
            want = {t["local_port"]: t for t in tasks}
            # a) 停掉「已删除」或「参数已变」的任务（先停干净再起，避免端口冲突）
            for port in list(running):
                ent = running[port]
                if port in want and task_signature(ent["task"]) == task_signature(want[port]):
                    continue
                ent["stop"].set()
                ent["thread"].join(timeout=5)
                running.pop(port)
                print(f"[*] 任务 127.0.0.1:{port} "
                      f"{'参数已变更，重启' if port in want else '已从配置移除，停止'}",
                      flush=True)
            # b) 启动新任务 / 重启已退出的任务
            for port, task in want.items():
                ent = running.get(port)
                if ent and ent["thread"].is_alive():
                    continue
                if ent:
                    print(f"[*] 任务 127.0.0.1:{port} 已退出，重新启动", flush=True)
                stop_event = threading.Event()
                th = threading.Thread(target=run_task, args=(task, stop_event),
                                      daemon=True, name=f"fwd-{port}")
                th.start()
                running[port] = {"task": task, "sig": task_signature(task),
                                 "stop": stop_event, "thread": th}
                if not ent:
                    print(f"[+] 已启动转发任务: 127.0.0.1:{port} "
                          f"-> 远端映射端口 {task['remote_local_port'] or '最近一条'}", flush=True)

        time.sleep(2)


def main():
    parser = argparse.ArgumentParser(
        description="xfeichong 客户端：本地TCP转发到NAT映射地址",
        epilog="brew services 管理示例: brew services start xfeichong-client")
    parser.add_argument("command", nargs="?", choices=["init"], default=None,
                        help="init = 仅生成配置模板并退出（默认为守护模式）")
    parser.add_argument("--config", "-c", default=str(DEFAULT_CONFIG),
                        help=f"配置文件路径（默认 {DEFAULT_CONFIG}）")
    args = parser.parse_args()
    config_path = Path(os.path.expanduser(args.config))

    if args.command == "init":
        if config_path.exists():
            print(f"[*] 配置文件已存在，不覆盖: {config_path}")
        else:
            write_template(config_path)
            print(f"[+] 已生成配置模板: {config_path}")
            print(f"[*] 请编辑该文件填入 appkey（数组里每个元素 = 一个转发任务，可配多个），"
                  f"然后运行: xfeichong-client（或 brew services start xfeichong-client）")
        return

    run_daemon(config_path)


if __name__ == "__main__":
    main()
